// Dados das 10 casas. Valores = estimativas da equipe (ver README).
const CASAS = [
  {
    "id": 1,
    "nome": "Smart Starter",
    "cor": "#38BDF8",
    "nivel": "Básico",
    "area": 55,
    "comodos": "2 quartos · 1 banheiro · área de serviço · garagem pequena",
    "dif": "Primeira automação, acessível",
    "preco": "R$ 165 mil a R$ 200 mil",
    "tec": [
      "Lâmpadas, interruptores e tomadas inteligentes",
      "Sensor de presença",
      "Smart TV e assistente de voz",
      "Wi-Fi e câmera na entrada"
    ]
  },
  {
    "id": 2,
    "nome": "Smart Comfort",
    "cor": "#38BDF8",
    "nivel": "Básico/Intermediário",
    "area": 85,
    "comodos": "3 quartos · 2 banheiros · área de serviço · garagem",
    "dif": "Conforto e portão automático",
    "preco": "R$ 270 mil a R$ 330 mil",
    "tec": [
      "Iluminação automatizada",
      "Sensores de presença e tomadas inteligentes",
      "Ar-condicionado inteligente",
      "Câmeras externas, portão automático, pontos de TV e rede"
    ]
  },
  {
    "id": 3,
    "nome": "Smart Family",
    "cor": "#34D399",
    "nivel": "Intermediário",
    "area": 120,
    "comodos": "3 quartos · suíte · sala de jantar · garagem para 2 carros",
    "dif": "Rotina e segurança da família",
    "preco": "R$ 400 mil a R$ 490 mil",
    "tec": [
      "Sensores de presença e iluminação automática",
      "Fechadura inteligente e câmeras",
      "Ar-condicionado inteligente e robô aspirador",
      "Assistentes de voz, rede estruturada e Access Point"
    ]
  },
  {
    "id": 4,
    "nome": "Smart Pet",
    "cor": "#34D399",
    "nivel": "Intermediário",
    "area": 150,
    "comodos": "3 quartos · suíte · escritório · área externa · garagem",
    "dif": "Pensada para famílias com pets",
    "preco": "R$ 530 mil a R$ 650 mil",
    "tec": [
      "Alimentador automático para cães",
      "Câmeras para pets e bebedouro inteligente",
      "Robô aspirador e sensores",
      "Iluminação automática, ar inteligente e voz"
    ]
  },
  {
    "id": 5,
    "nome": "Smart Security",
    "cor": "#34D399",
    "nivel": "Intermediário/Avançado",
    "area": 190,
    "comodos": "4 quartos · 2 suítes · escritório · área gourmet · garagem para 2 carros",
    "dif": "Foco total em segurança",
    "preco": "R$ 750 mil a R$ 910 mil",
    "tec": [
      "Câmeras internas e externas, com IA",
      "Fechadura, sensores de abertura e alarme inteligente",
      "Campainha com câmera e controle pelo celular",
      "Access Points e rede estruturada"
    ]
  },
  {
    "id": 6,
    "nome": "Smart Eco",
    "cor": "#F5A524",
    "nivel": "Avançado",
    "area": 210,
    "comodos": "3 quartos · suíte · escritório · área gourmet · jardim · garagem",
    "dif": "Economia e eficiência",
    "preco": "R$ 900 mil a R$ 1,1 milhão",
    "tec": [
      "Sensores de luminosidade e presença",
      "Monitoramento de consumo de energia",
      "Irrigação automática e cortinas automatizadas",
      "Ar inteligente, robô aspirador e segurança"
    ]
  },
  {
    "id": 7,
    "nome": "Smart Entertainment",
    "cor": "#F5A524",
    "nivel": "Avançado",
    "area": 270,
    "comodos": "4 quartos · 2 suítes · sala de cinema · área gourmet · piscina",
    "dif": "Entretenimento totalmente integrado",
    "preco": "R$ 1,3 a R$ 1,6 milhão",
    "tec": [
      "Home theater e iluminação de cinema",
      "Áudio distribuído e som externo",
      "Cortinas automáticas e automação da piscina",
      "TVs inteligentes, voz e rede de alta velocidade"
    ]
  },
  {
    "id": 8,
    "nome": "Smart Luxury",
    "cor": "#F5A524",
    "nivel": "Avançado",
    "area": 330,
    "comodos": "4 quartos · 3 suítes · academia · área gourmet · piscina · garagem para 3 carros",
    "dif": "Casa totalmente automatizada",
    "preco": "R$ 1,8 a R$ 2,2 milhões",
    "tec": [
      "Fechaduras inteligentes e câmeras com IA",
      "Controle de iluminação e cortinas",
      "Áudio distribuído e home theater",
      "Robôs de limpeza e sensores em todos os ambientes"
    ]
  },
  {
    "id": 9,
    "nome": "Smart AI",
    "cor": "#C084FC",
    "nivel": "Muito avançado",
    "area": 400,
    "comodos": "4 suítes · cinema · sala gamer · academia · escritório · piscina · jardim",
    "dif": "A IA coordena toda a casa",
    "preco": "R$ 2,4 a R$ 3 milhões",
    "tec": [
      "IA que aprende as rotinas dos moradores",
      "Cenas automáticas e identificação de presença",
      "Detecção de situações anormais",
      "Segurança e consumo de energia otimizados"
    ]
  },
  {
    "id": 10,
    "nome": "Smart Future",
    "cor": "#C084FC",
    "nivel": "Tecnologia máxima",
    "area": 520,
    "comodos": "5 suítes · cinema · sala gamer · academia · spa · piscina · quarto técnico",
    "dif": "A casa mais tecnológica",
    "preco": "R$ 3,7 a R$ 4,5 milhões",
    "tec": [
      "IA central e painel de controle",
      "Reconhecimento de padrões e sensores em toda a casa",
      "Home theater, áudio distribuído e robôs de limpeza",
      "Quarto técnico para servidores e rede de alta velocidade"
    ]
  }
];
