// Renderiza filtros, cards (foto/planta) e modal com a planta ampliada.
const grupos = ['Todas', 'Básico', 'Intermediário', 'Avançado', 'Futurista'];
const pertence = (casa, g) =>
  g === 'Todas' ||
  (g === 'Básico' && casa.id <= 2) ||
  (g === 'Intermediário' && casa.id >= 3 && casa.id <= 5) ||
  (g === 'Avançado' && casa.id >= 6 && casa.id <= 8) ||
  (g === 'Futurista' && casa.id >= 9);

const n2 = (id) => String(id).padStart(2, '0');
// Tenta foto real (assets/fotos/casa-01.jpg). Se não existir, usa a ilustração .svg.
const fotoSrc = (id) => `assets/fotos/casa-${n2(id)}.jpg`;
const fotoFallback = (id) => `assets/fotos/casa-${n2(id)}.svg`;
const plantaSrc = (id) => `assets/plantas/planta-${n2(id)}.svg`;

const grade = document.getElementById('grade');
const filtros = document.getElementById('filtros');
const modal = document.getElementById('modal');
const modalCorpo = document.getElementById('modal-corpo');

function cardHTML(c) {
  return `
  <article class="card" data-id="${c.id}">
    <figure>
      <img src="${fotoSrc(c.id)}" alt="Casa ${c.nome}" onerror="this.onerror=null;this.src='${fotoFallback(c.id)}'">
      <div class="abas">
        <button class="ativo" data-aba="foto">Foto</button>
        <button data-aba="planta">Planta</button>
      </div>
    </figure>
    <div class="corpo">
      <span class="nivel" style="color:${c.cor}">Casa ${c.id} · ${c.nivel}</span>
      <h3>${c.nome}</h3>
      <p>≈${c.area} m² · ${c.comodos}</p>
      <ul>${c.tec.map((t) => `<li>${t}</li>`).join('')}</ul>
      <div class="preco" style="color:${c.cor}">${c.preco}<small>estimativa da equipe</small></div>
      <button class="btn" style="color:${c.cor}" data-detalhes>Ver planta completa</button>
    </div>
  </article>`;
}

function render(grupo) {
  grade.innerHTML = CASAS.filter((c) => pertence(c, grupo)).map(cardHTML).join('');
}

filtros.innerHTML = grupos.map((g, i) => `<button class="${i === 0 ? 'ativo' : ''}">${g}</button>`).join('');
filtros.addEventListener('click', (e) => {
  if (e.target.tagName !== 'BUTTON') return;
  filtros.querySelectorAll('button').forEach((b) => b.classList.remove('ativo'));
  e.target.classList.add('ativo');
  render(e.target.textContent);
});

grade.addEventListener('click', (e) => {
  const card = e.target.closest('.card');
  if (!card) return;
  const casa = CASAS.find((c) => c.id === Number(card.dataset.id));
  const aba = e.target.dataset.aba;
  if (aba) {
    const img = card.querySelector('figure img');
    img.onerror = null;
    if (aba === 'planta') img.src = plantaSrc(casa.id);
    else { img.onerror = () => { img.onerror = null; img.src = fotoFallback(casa.id); }; img.src = fotoSrc(casa.id); }
    card.querySelectorAll('.abas button').forEach((b) => b.classList.toggle('ativo', b === e.target));
  }
  if (e.target.hasAttribute('data-detalhes')) {
    modalCorpo.innerHTML = `
      <h3 style="margin:0 0 4px;font-size:32px">${casa.nome}</h3>
      <p style="margin:0 0 16px;color:${casa.cor}">${casa.nivel} · ${casa.dif}</p>
      <div class="modal-grid">
        <img src="${plantaSrc(casa.id)}" alt="Planta baixa ${casa.nome}">
        <div>
          <p>≈${casa.area} m² · ${casa.comodos}</p>
          <ul>${casa.tec.map((t) => `<li>${t}</li>`).join('')}</ul>
          <p style="font-size:26px;font-weight:700;color:${casa.cor}">${casa.preco}<br><small style="font-size:14px;font-weight:400;color:#A3B2D3">estimativa da equipe</small></p>
        </div>
      </div>`;
    modal.showModal();
  }
});

document.getElementById('fechar').addEventListener('click', () => modal.close());
modal.addEventListener('click', (e) => { if (e.target === modal) modal.close(); });

render('Todas');
