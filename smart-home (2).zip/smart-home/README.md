# Smart Home — Landing page (HTML/CSS/JS puro)

## Como abrir no VS Code
1. Extraia a pasta e abra no VS Code (`File > Open Folder`).
2. Instale a extensão **Live Server** e clique em *Go Live* (ou dê duplo clique em `index.html`).

## Estrutura
- `index.html` — página (logo, hero, cards, método, rodapé)
- `css/style.css` — visual
- `js/data.js` — dados das 10 casas (nome, área, tecnologias, preço)
- `js/app.js` — filtros, cards com abas Foto/Planta e modal da planta
- `assets/plantas/planta-01..10.svg` — plantas com cômodos nomeados e pontos de tomadas, interruptores, sensores, câmeras, rede, TV e central
- `assets/fotos/casa-01..10.svg` — ilustrações (não são fotos reais)

## Colocar fotos reais
Salve suas fotos como `assets/fotos/casa-01.jpg` ... `casa-10.jpg`.
Se o `.jpg` existir, a página usa a foto; senão, usa a ilustração `.svg`.

## Valores
Estimativas da equipe: área × CUB-CE R8N (R$ 2.458,13/m², ago/2026) × fator de padrão
+ automação (R$ 60 a R$ 600/m²), tudo × 1,3, com faixa de ±10%.
